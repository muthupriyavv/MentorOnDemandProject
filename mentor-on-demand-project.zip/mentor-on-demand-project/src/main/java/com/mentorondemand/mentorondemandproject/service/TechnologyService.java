package com.mentorondemand.mentorondemandproject.service;

import com.mentorondemand.mentorondemandproject.model.Technologies;

public interface TechnologyService {
	
	public Technologies addTechnology(Technologies tech);

}
