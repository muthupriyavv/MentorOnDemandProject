package com.mentorondemand.mentorondemandproject.service;

import java.sql.SQLException;

import org.springframework.stereotype.Service;

import com.mentorondemand.mentorondemandproject.model.MentorSkills;


public interface MentorSkillsService {
    public MentorSkills addskills(MentorSkills mentorskills)  throws SQLException;
}
