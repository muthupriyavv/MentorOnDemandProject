package com.mentorondemand.mentorondemandproject.controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.mentorondemand.mentorondemandproject.model.Mentor;
import com.mentorondemand.mentorondemandproject.model.MentorSkills;
import com.mentorondemand.mentorondemandproject.model.User;
import com.mentorondemand.mentorondemandproject.service.MentorService;
import com.mentorondemand.mentorondemandproject.service.UserService;

@Controller
public class UserController {

	/*
	 * @RequestMapping(value = "/signup", method = RequestMethod.GET) public String
	 * signup() { return "signup"; }
	 */
	
	@Autowired
	private UserService userservice;
	
	@Autowired
	private MentorService mentorservice;
	
	
	
	 
	 @RequestMapping(path="/signup", method = RequestMethod.GET)
	    public ModelAndView signup(ModelMap map) throws SQLException {
	          ModelAndView mav = null;
	          map.addAttribute("user", new User());
	          map.addAttribute("mentor", new Mentor());
	          mav = new ModelAndView("signup");
	          return mav;

	    } 
	 
	 
	 @RequestMapping(value = "/addUser", method = RequestMethod.POST)
	    public ModelAndView registerUser( @ModelAttribute("user") @Valid User user, BindingResult result,
	                  HttpServletRequest request, HttpSession session, ModelMap map) throws SQLException {
	           ModelAndView mav = null;
	           if (result.hasErrors()) {
	                  mav = new ModelAndView("signup");
	                  return mav;
	           }
	       System.out.println(user);
	       userservice.registerUser(user);
	       mav = new ModelAndView("redirect:/Login");
	           return mav;

	    }
	 
	 
	 
	 @RequestMapping(path="/Login", method = RequestMethod.GET)
	    public ModelAndView login(ModelMap map) throws SQLException {
	          ModelAndView mav = null;
	          map.addAttribute("userlogin", new User());
	          map.addAttribute("mentorlogin", new Mentor());
	          mav = new ModelAndView("Login");
	          return mav;

	    } 
	 
	
	 @RequestMapping(path= "/userLogin", method = RequestMethod.POST)
	    public ModelAndView registerCompany( @ModelAttribute("userlogin") @Valid User user, BindingResult result,
	                  HttpServletRequest request, HttpSession session, ModelMap map) throws SQLException {

	     ModelAndView mav = null;
	     String email = user.getEmail();
	     List<User> user1 = userservice.findByEmail(email);
	     User user2 = user1.get(0);
	     System.out.println(user.getEmail()+" "+user2.getEmail());
	     System.out.println(user.getPassword()+" "+user2.getPassword());
	     if (( user.getEmail().equals(user2.getEmail())) && (user.getPassword().equals(user2.getPassword())))
	     {
	                  
	    	 mav = new ModelAndView("UserLandingPage");
	            
	     } 
	     else 
	     {

	         mav = new ModelAndView("LoginError", "message", "Invalid Username or Password");
	     }
	  
	     return mav;


	    }
 
	 @RequestMapping(value="/searchTech")
	 public String Search(@RequestParam("search") String timeslot) {

	      if(timeslot != null){
	       mentorservice.findByTimeSlot(timeslot);
	      }

	       return "search";
	   }
	}
	 
	 


