package com.mentorondemand.mentorondemandproject.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mentorondemand.mentorondemandproject.model.MentorSkills;

@Repository
public interface MentorSkillsDao  extends  JpaRepository<MentorSkills,Integer>{

}
